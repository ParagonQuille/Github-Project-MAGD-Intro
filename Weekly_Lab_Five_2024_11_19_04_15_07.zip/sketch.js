function setup() {
  createCanvas(400, 400);
  background(220);
  ellipseMode(CORNERS);
  rectMode(CORNERS);
}

function draw() {
  ellipse(35, 35, 85, 85);
  rect(300, 60, 350, 110);
  rect(150, 150, 250, 250);
if (keyIsPressed == true){
  if (key == 'f') {
    if(mouseX>150 && mouseX<250 && mouseY>150 && mouseY<250 ){
      ellipse(mouseX, mouseY+100, mouseX+50, mouseY+150);
  }
  }
}
}
function mouseClicked() {
 if (mouseX > 35 && mouseX <85 && mouseY>35 && mouseY<85){
   rect(mouseX, mouseY+200, mouseX+50, mouseY+250);
 }
   if (mouseX > 300 && mouseX <350 && mouseY>60 && mouseY<110){
     ellipse(mouseX, mouseY+200, mouseX+50, mouseY+250);
   }
}
