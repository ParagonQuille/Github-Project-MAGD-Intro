function setup() {
  createCanvas(400, 400);
  background(220);
}

function draw() {
  fillGradient('linear', {
    from : [0, 0], // 
    to : [400, 400],
    steps : [
      color(0, 140, 80),
      color(0, 96, 164),
      color(72)
    ] 
});
 square(0, 0, 400);
fillGradient('radial', {
    from : [200, 200, 0], 
    to : [200, 200, 200], 
    steps : [
        color(200),
        color(0, 96, 164),
        color(0)
    ] 
});
  circle (200, 200, 300);
  
  fillGradient('conic', {
    from : [200, 200, 45],
    
    steps : [ 
        color(224,17,95),
        color(20, 168, 107),
        color(224,17,95),
       color(20, 168, 107),
      color(224,17,95),
      color(20, 168, 107),
        color(224,17,95),
       color(20, 168, 107),
      color(224,17,95)
    ]
    
  });
  ellipse (200, 200, 160, 80);
}