function setup() {
  createCanvas(400, 400);
  background(220);
  strokeWeight(1);
  rectMode(CENTER);
  angleMode(DEGREES);
}
function info(x){
  print(x + " squared is " + (x*x));
}
function star(x, y){
  translate(x, y);
  square(100, 100, 125);
  circle(100, 100, 150);
}
function draw() {
  info(5);
  for(let z = 0; z<100; z+=20){
  star(z, z);
  }
  push();
  fill(200);
  scale(0.5);
  rotate(25);
  star(0, 0);
  pop();
}
